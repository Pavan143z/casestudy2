export class Course
{id: number;
    name : string;
    duration: number; 
}