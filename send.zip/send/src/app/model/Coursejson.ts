export class Coursejson
{
    id: number;
    courseName : string;
    coursePrice: number;
    courseId: number;
  
}