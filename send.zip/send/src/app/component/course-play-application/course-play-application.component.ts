import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-play-application',
  templateUrl: './course-play-application.component.html',
  styleUrls: ['./course-play-application.component.css']
})
export class CoursePlayApplicationComponent implements OnInit {

  constructor() { }
 
  ngOnInit() {
  }

}
